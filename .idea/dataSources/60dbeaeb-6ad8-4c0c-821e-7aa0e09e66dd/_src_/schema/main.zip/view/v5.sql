CREATE VIEW v5 AS
  SELECT
    c.c_name,
    c.phone,
    p.vehicle_no
  FROM parking p, customer c
  WHERE (p.time_out - p.time_in) > 4
        AND p.cust_id = c.cust_id;
