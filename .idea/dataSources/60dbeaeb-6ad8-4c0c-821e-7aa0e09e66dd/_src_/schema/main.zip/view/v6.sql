CREATE VIEW v6
  AS
    SELECT sum(price)
    FROM menu m, customer c, orders o
    WHERE o.cust_id = c.cust_id
          AND m.menu_id = o.menu_id;
