CREATE VIEW v3 AS SELECT c.c_name,c.phone,p.vehicle_no
     FROM parking p, customer c 
     WHERE(p.time_out-p.time_in)>40000 AND p.c_id=c.c_id;
