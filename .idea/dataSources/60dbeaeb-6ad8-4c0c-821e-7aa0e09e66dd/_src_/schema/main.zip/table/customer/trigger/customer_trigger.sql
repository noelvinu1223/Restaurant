CREATE TRIGGER customer_trigger AFTER INSERT ON customer 
      BEGIN 
         INSERT INTO CUSTOMER_LOG (CUS_NAME, date_time) VALUES (new.c_name, datetime('now'));
END